-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (arm64)
--
-- Host: 103.198.175.81    Database: mtm_store_db
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order_status_history`
--

DROP TABLE IF EXISTS `order_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_status_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` varchar(30) DEFAULT NULL,
  `changed_by` varchar(50) DEFAULT NULL,
  `from_status` varchar(255) DEFAULT NULL,
  `to_status` varchar(255) DEFAULT NULL,
  `change_reason` varchar(255) DEFAULT NULL,
  `changed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_status_history_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_status_history`
--

LOCK TABLES `order_status_history` WRITE;
/*!40000 ALTER TABLE `order_status_history` DISABLE KEYS */;
INSERT INTO `order_status_history` VALUES (1,'202526#84','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-13 13:45:48'),(2,'202526#84','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-13 13:45:52'),(3,'202526#87','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-13 14:01:48'),(4,'202526#87','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-13 14:02:43'),(5,'202526#87','admin','fulfill:True, delivery:shipped','fulfill:True, delivery:delivered','Status updated via delivered action','2025-05-13 14:03:07'),(6,'202526#96','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-14 09:10:56'),(7,'202526#96','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-14 09:11:11'),(8,'202526#96','admin','fulfill:True, delivery:shipped','fulfill:True, delivery:delivered','Status updated via delivered action','2025-05-14 09:11:24'),(9,'202526#99','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-14 09:40:16'),(10,'202526#99','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-14 09:40:29'),(11,'202526#99','admin','fulfill:True, delivery:shipped','fulfill:True, delivery:delivered','Status updated via delivered action','2025-05-14 09:40:44'),(12,'202526#101','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-14 10:08:59'),(13,'202526#101','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-14 10:09:15'),(14,'202526#101','admin','fulfill:True, delivery:shipped','fulfill:True, delivery:delivered','Status updated via delivered action','2025-05-14 10:09:26'),(15,'202526#128','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-16 19:40:10'),(16,'202526#128','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-16 19:40:10'),(17,'202526#128','admin','fulfill:True, delivery:shipped','fulfill:True, delivery:delivered','Status updated via delivered action','2025-05-16 19:40:10'),(18,'202526#134','admin','fulfill:False, delivery:intransit','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-16 20:47:09'),(19,'202526#133','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-17 07:51:40'),(20,'202526#155','admin','fulfill:False, delivery:pending','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-19 17:16:32'),(21,'202526#155','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-19 17:16:32'),(22,'202526#155','admin','fulfill:True, delivery:shipped','fulfill:True, delivery:delivered','Status updated via delivered action','2025-05-19 17:16:32'),(23,'202526#158','admin','fulfill:False, delivery:intransit','fulfill:True, delivery:processing','Status updated via fulfill action','2025-05-19 17:16:32'),(24,'202526#158','admin','fulfill:True, delivery:processing','fulfill:True, delivery:shipped','Status updated via shipped action','2025-05-19 17:16:32'),(25,'202526#158','admin','fulfill:True, delivery:shipped','fulfill:True, delivery:delivered','Status updated via delivered action','2025-05-19 17:16:32');
/*!40000 ALTER TABLE `order_status_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 10:44:08
