-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (arm64)
--
-- Host: 103.198.175.81    Database: mtm_store_db
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `model_specifications`
--

DROP TABLE IF EXISTS `model_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_specifications` (
  `spec_id` int NOT NULL AUTO_INCREMENT,
  `model_id` int NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`spec_id`),
  KEY `model_id` (`model_id`),
  CONSTRAINT `model_specifications_ibfk_1` FOREIGN KEY (`model_id`) REFERENCES `product_models` (`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_specifications`
--

LOCK TABLES `model_specifications` WRITE;
/*!40000 ALTER TABLE `model_specifications` DISABLE KEYS */;
INSERT INTO `model_specifications` VALUES (4,3,'Brand:','Real Time'),(5,3,'Model Number:','Pro 1100+'),(6,3,'Warranty:','1 year'),(7,3,'Origin:','India'),(8,4,'Brand:','Real Time'),(9,4,'Model Number:','Pro-1400'),(10,4,'Warranty:','1 year'),(11,4,'Manufactured by:','Real Time Biometrics'),(12,4,'OS Support:','Linux'),(13,5,'Model Number:','Pro 1700'),(14,5,'Origin: ','India'),(15,5,'CPU:','Quad-core, 1.7G'),(16,5,'User capacity: ','5000/10000'),(17,5,'Identification Modes: ','Face, Card, Password'),(18,6,'Device Type: ','Portable Multi-Fingerprint Scanner'),(19,6,'Scanning Area:','Wide, supports all ten fingerprints'),(20,6,'Capture Mode:',' Four-finger slaps & thumbs of both hands'),(21,6,'Flat & Rolled Fingerprints:','Yes'),(22,6,'Resolution:','High-resolution imaging');
/*!40000 ALTER TABLE `model_specifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 10:44:48
