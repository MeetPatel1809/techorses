-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (arm64)
--
-- Host: 103.198.175.81    Database: mtm_store_db
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product_specifications`
--

DROP TABLE IF EXISTS `product_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_specifications` (
  `spec_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`spec_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_specifications_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_specifications`
--

LOCK TABLES `product_specifications` WRITE;
/*!40000 ALTER TABLE `product_specifications` DISABLE KEYS */;
INSERT INTO `product_specifications` VALUES (7,32,'Protocols','NMEA 0183 - GGA, GSA, GSV, RMC, VTG'),(19,40,'Operating Systems','Compatible with Windows and Android platforms'),(21,41,'Model','Pax D180'),(22,41,'Type','Mobile'),(23,41,'OS','Android, Windows'),(24,41,'Connnectivity','USB, Bluetooth'),(25,41,'Compatible in Banks','PNB, BOB, UBI, CBI, UCO'),(27,42,'Model','Evreycom EC-58BT'),(28,42,'Paper Width','57.5 ± 0.5 mm'),(29,42,'Connnectivity','USB, Bluetooth'),(30,42,'Resolution','203 dpi (dots per inch)'),(31,42,'Dimensions','185 x 115 x 130 mm'),(32,42,'Paper Roll Diameter','Up to 83 mm'),(33,42,'Weight','Approx. 0.6 kg'),(34,42,'Type','Standalone'),(35,42,'Print Speed','Up to 120 mm/s'),(37,43,'Sensor Type','Optical'),(38,43,'Light Source','Red LED'),(39,43,'Model','Mantra MFS110 L1'),(40,43,'Dimensions (L x W x H)','61 mm x 91 mm x 54 mm'),(41,43,'Operating Current','< 90 mA'),(42,43,'Weight','0.140 kg'),(43,43,'Resolution','500 DPI ± 2%'),(46,46,'Model','TATVIK POS-5805DD'),(47,47,'Model','MT580P'),(48,48,'Paper Width','80mm'),(49,49,'Model','Evolute Impress+'),(50,50,'Model','Tatvik TPOS58'),(52,51,'Grayscale Depth','8 bits per pixel'),(53,51,'Image Resolution','500 x 500 dpi'),(54,51,'Dimensions','80 x 41 x 40 mm'),(55,51,'Sensor Type','optical'),(56,51,'Scanning Light Source','Ultra Red (940nm)'),(57,51,'Connectivity','USB, Type-C'),(58,52,'Output Image Format','KIND1 to KIND7 with JPEG2000 compression'),(59,53,'Weight','Approximately 7.8 kg'),(60,54,'Model','Evolute Falcon L1'),(61,55,'Model','ASP CX588'),(62,52,'Output Image Format-2','KIND1 to KIND7 with JPEG2000 compression-2'),(63,56,'Data Captured','Latitude and Longitude'),(64,57,'rom','12345'),(65,58,'ram','value'),(66,59,'  ncn','Real Time'),(67,59,'Model Number:','Pro 1100+'),(68,60,'Ram','10Gb'),(74,62,'Ram','10Gb'),(75,63,'type','sporty'),(76,64,'quality','plastic'),(77,65,'Ram','10Gb'),(78,66,'Model','Xpresso ROINET Mini ATM Machine – VM30'),(79,66,'Standard','250mAh Li-ion battery');
/*!40000 ALTER TABLE `product_specifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 10:45:22
