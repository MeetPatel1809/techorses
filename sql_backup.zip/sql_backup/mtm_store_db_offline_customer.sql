-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (arm64)
--
-- Host: 103.198.175.81    Database: mtm_store_db
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `offline_customer`
--

DROP TABLE IF EXISTS `offline_customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offline_customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `google_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `mobile` (`mobile`),
  UNIQUE KEY `google_id` (`google_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offline_customer`
--

LOCK TABLES `offline_customer` WRITE;
/*!40000 ALTER TABLE `offline_customer` DISABLE KEYS */;
INSERT INTO `offline_customer` VALUES (5,'Deva','1234567890','customer@example.com','offline_customer',NULL),(11,'John Doe','1234567891','john@example.com','offline_customer',NULL),(12,'Amaan Sodagar','6398521470','amaan@gmail.com','offline_customer',NULL),(13,'Saquib','9312347643','saquibsiraj@outlook.com','offline_customer',NULL),(15,'raju','123657890','','offline_customer',NULL),(16,'hasan','7777777777','ashish111@gmail.com','offline_customer',NULL),(17,'Amaan Sodagar','6699335522','sodagaramaan78692@gmail.com','offline_customer',NULL),(18,'meeee','123456790','meeee@gmail.com','offline_customer',NULL),(19,'Mohammad Amaan','1114447770','sodagaramaan786@gmail.com','offline_customer',NULL),(20,'Chandan Das','6362302795','chandan.das@fiaglobal.com','offline_customer',NULL),(21,'meet koladiya','06352272322','meet@gmail.com','offline_customer',NULL),(22,'UTTAM DAS','8670766798','uttamdaspan5@gmail.com','offline_customer',NULL),(36,'Umesh Das','7870846680','support@mtm-store.com','offline_customer',NULL),(39,'Abhishek','9654553134','psychooabhiii@gmail.com','offline_customer',NULL),(48,'Ajay Samal','9371598210','sales@mtm-store.com','offline_customer',NULL),(49,'Avtar singh','9872607737','Skyblue0505@gmail.com','offline_customer',NULL),(50,'Rizwan Ahmad','9415429644','idealmathauli@gmail.com','offline_customer',NULL),(51,'Purandar Kumar','9616332893','purandarkumar709@gmail.com','offline_customer',NULL),(52,'S.Royalbritto','6374295860','royalbritto92@gmail.com','offline_customer',NULL),(53,'Ravi Kushwah','Ravi Kushwah','rk7666285@gmail.com','offline_customer',NULL),(54,'Ravi Kushwah','9129325526','rk7666285@gmail.com','offline_customer',NULL),(55,'ATUL SINGH','8756446648','Atulsingh1011@gmail.com','offline_customer',NULL),(56,'Navneet Jain','8115762555','','offline_customer',NULL),(57,'Harihar Narayan','8400545545','','offline_customer',NULL),(58,'Pransingh Kushwaha','7897680170','','offline_customer',NULL);
/*!40000 ALTER TABLE `offline_customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 10:44:36
