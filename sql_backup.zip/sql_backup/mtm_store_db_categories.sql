-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (arm64)
--
-- Host: 103.198.175.81    Database: mtm_store_db
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (6,'Biometric','/product_images/008a9bd5f8414c66b059d9e8fceafea2_Biometric.png'),(8,'Electronics','/product_images/3d2693ba8b284baf91b96239e2f292c7_Electronics.webp'),(9,'Mobiles & Tabs','/product_images/b36837c0c9e747199f77a9455ee2a61d_Mobile.webp'),(10,'GPS Device','/product_images/8a82e7bd4be94f7b9dab17e2d0341f69_GPS_Device.webp'),(11,'Medical Device','/product_images/b655f418badf4218bb78dbc7b848fb44_Medical_Device.jpg'),(12,'Computer','/product_images/08b6a5e6bd0f4109b558dd23b37d1791_Computer.jpg'),(14,'Software','/product_images/ee42aa479a7440cc82e25d423a5abf73_Software.jpeg'),(15,'mPOS','/product_images/08bb4ccf982d40afbaa586dc3377f4dd_Pax_D180-front1.jpg'),(16,'POS Machine','/product_images/d65ba6f3d63f4b3c9d818f6844a836c7_Pax_D180-front1.jpg'),(18,'mPOS Machine','/product_images/73111e94489b43b2a453c7c1976b7332_Pax_D180-front1.jpg'),(21,'Biometric FIngerprint Scanner','/product_images/f11f22b43d1f48c88056ac5fc1ce4402_Idemia_MSO1300_RD_L1_Morpho_L1.jpeg'),(22,'biometric machine','/product_images/2235585038074e2db8331c53b6d5a6f7_CX588-Cover.webp'),(23,'Thermal Printer','/product_images/fe5d3edca70f4e6f816bd6f527627670_EC58-Cover.webp'),(24,'Iris Scanner','/product_images/ba0504cbd6e24135a968c63d4bc93e0e_MIS100V2_IRIS_4.jpeg'),(25,'Printers','/product_images/01eaaf1f8ef84c15b0f219cce6d00685_Epson_PLQ-35_Passbook_Printer5.jpeg'),(26,'Test','/product_images/56d2a041db02471c8155f63ab1e7d749_category.jpg');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 10:45:19
