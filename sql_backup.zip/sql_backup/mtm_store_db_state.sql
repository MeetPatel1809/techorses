-- MySQL dump 10.13  Distrib 8.0.41, for macos15 (arm64)
--
-- Host: 103.198.175.81    Database: mtm_store_db
-- ------------------------------------------------------
-- Server version	8.0.42-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `state` (
  `state_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `abbreviation` varchar(10) NOT NULL,
  PRIMARY KEY (`state_id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `abbreviation` (`abbreviation`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` VALUES (1,'Andhra Pradesh','AP'),(2,'Arunachal Pradesh','AR'),(3,'Assam','AS'),(4,'Bihar','BR'),(5,'Chhattisgarh','CG'),(6,'Goa','GA'),(7,'Gujarat','GJ'),(8,'Haryana','HR'),(9,'Himachal Pradesh','HP'),(10,'Jharkhand','JH'),(11,'Karnataka','KA'),(12,'Kerala','KL'),(13,'Madhya Pradesh','MP'),(14,'Maharashtra','MH'),(15,'Manipur','MN'),(16,'Meghalaya','ML'),(17,'Mizoram','MZ'),(18,'Nagaland','NL'),(19,'Odisha','OD'),(20,'Punjab','PB'),(21,'Rajasthan','RJ'),(22,'Sikkim','SK'),(23,'Tamil Nadu','TN'),(24,'Telangana','TS'),(25,'Tripura','TR'),(26,'Uttar Pradesh','UP'),(27,'Uttarakhand','UK'),(28,'West Bengal','WB'),(29,'Andaman and Nicobar Islands','AN'),(30,'Chandigarh','CH'),(31,'Dadra and Nagar Haveli and Daman and Diu','DN'),(32,'Delhi','DL'),(33,'Jammu and Kashmir','JK'),(34,'Ladakh','LA'),(35,'Lakshadweep','LD'),(36,'Puducherry','PY');
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 10:44:45
